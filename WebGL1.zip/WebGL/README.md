# WebGL

Project that accompanies VGGI credit module.

Visit vggi-kpi.blogspot.com for more information